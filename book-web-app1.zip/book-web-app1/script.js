function showHome() {
  document.getElementById("content").innerHTML = "<p>This is the homepage content.</p>";
}

function showBooks() {
  document.getElementById("content").innerHTML = "<p>Page is coming.</p>";
}